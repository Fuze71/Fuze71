public class MadLib {
    public static void main(String[] args){
        String[] names ={"John", "Jerry","Greg","Jeff"};
        String[] adjective ={"large", "small","massive","tiny"};
        String[] animals ={"sheep", "chicken","cow","dog"};
        int randomn = (int) (Math.random() * 4);
        int randoma1 = (int) (Math.random() * 4);
        int randoma2 = (int) (Math.random() * 4);
        System.out.println(names[randomn]+" had a "+ adjective[randoma1]+" "+ animals[randoma2]+".");
    }
}